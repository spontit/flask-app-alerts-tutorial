# flask-app-alerts-tutorial
Send push notifications when you Flask has a code 500, internal server error - or any other error.
